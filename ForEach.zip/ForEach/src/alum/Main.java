package alum;

public class Main {


	
	
public void notas() {	
	int [] mi_matriz= new int [5];
	mi_matriz[0]=1;
	mi_matriz[1]=2;
	mi_matriz[2]=3;
	mi_matriz[3]=4;
	mi_matriz[4]=5;
	
	for(int guille: mi_matriz) {
		System.out.println(guille);
	    }
	

//for(int j=0; j<5 ;j++) {
		
	//	System.out.print(mi_matriz[j]);
		
	  //  }
		
}	
public void nombres() {
	
	String []nombres ={"raul ","ramon ","pedro ","jose"};
	
	
	for(String guillermo: nombres) {

		 System.out.printf(guillermo);
		 
		 }
	
	//for(int j=0; j<5 ;j++) {
	//	 System.out.println(nombres[j]+mi_matriz);
		// }
 }
}
