package alum;

public class Uso_Empleado {

	public static void main(String[] args) {
      
		Main n1 = new Main();
	
	n1.nombres(); 
	n1.notas();
	
	
	}
	
}